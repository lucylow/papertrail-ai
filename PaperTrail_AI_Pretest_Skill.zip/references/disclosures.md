# Disclosures, boundaries, and validation

## Third-party components and licenses

The submitted Skill package contains only original Markdown instructions and contains no third-party code, open-source library, script, executable, binary, credential, or external API integration.

The UGREEN Skill Creation Tool package, `uliya-skill-kit` v0.7.3, was consulted as the official authoring reference and its static checker was used to check this Skill. Source: [UGREEN Hackathon Starter Kit](https://ai.ugreen.com/pages/hackathon-starter-kit), which links to the [official tool archive](https://cdn.shopify.com/s/files/1/0630/9416/1602/files/uliya-skill-kit-0.7.3-en.zip?v=1790578898). The tool archive is not included in this submission. No separate license notice was found in that archive; no code from it is redistributed.

The runtime dependency is the UGREEN NAS platform's registered expert agents and supported capabilities, as described by the official package's capability catalog. These platform interfaces are not third-party libraries bundled in this Skill. Runtime access and applicable platform terms are controlled by UGREEN.

## AI tools and their use

Manus AI was used to draft and refine the proposal and original orchestration instructions and to compare them with the published submission requirements and official capability catalog. UGREEN checker format 2.0.0 returned `static-pass` with no diagnostics. Static validation does not verify installation or NAS execution. The runtime model/provider is not hard-coded: the Skill expects the model configuration available in the target NAS environment. No exact model, local-inference behavior, or on-device execution has yet been tested or claimed.

## Original functionality developed for this Hackathon

PaperTrail AI's original contribution is an orchestration workflow that scopes search to a user-authorized folder, extracts finance fields from identified business documents, rechecks requested totals with a separate document-grounded question, compares related records, and synthesizes findings with source paths. It labels discrepancies as review flags, avoids claiming that absent documents are missing without an expected schedule, and makes report saving optional and approval-gated.

## Known limits and risk controls

Extraction may be incomplete or incorrect, especially for low-quality scans, unusual layouts, multiple currencies, taxes, or ambiguous vendor names. Totals must preserve period and currency and must identify included source records. If evidence is partial or values conflict, the Skill must state that limitation and avoid an unsupported total. A contract/invoice difference is not proof of overbilling. The Skill does not perform payment approval, accounting-platform updates, automatic monitoring, or background ingestion. Final behavior, permissions, model configuration, and output references remain subject to testing on the assigned UGREEN AI NAS.

## Finalist test plan

Planned core checks cover duplicate-aware totals, contract reconciliation, and a user-supplied billing schedule. Edge and repeat-use checks cover unconfirmed matches, unreadable amounts, fresh discovery, permission scope, approval, cleanup, and catalog drift. Detailed synthetic inputs and NAS setup/removal checks are in [acceptance scenarios](test-cases.md). These are plans, not NAS runtime results.

## Official references

- [UGREEN Hackathon 2026 on AI NAS — Devpost](https://ugreenhackathon.devpost.com/)
- [UGREEN Hackathon Starter Kit](https://ai.ugreen.com/pages/hackathon-starter-kit)
