
## 6. User-supplied expected billing schedule

Give PaperTrail a synthetic schedule listing Cedar Office Demo invoices expected for January, February, and March 2026. Place only the January and March invoices in the authorized folder, plus an unrelated vendor invoice. Ask which expected Cedar invoices were not located.

Expected: identify February as “not found in the searched folder,” cite the supplied schedule and the scoped search result, and exclude the unrelated vendor. Do not claim the invoice does not exist elsewhere or accuse the vendor of missing a bill. This tests a schedule-versus-evidence workflow beyond single-file extraction.

## 7. Capability-version drift

Record the target device's active UGREEN tool/catalog versions and compare each required capability-to-agent mapping with this package's authoring reference (Uliya Skill Creation Tool v0.7.3, capability catalog v2.0.0). If an action or mapping differs, expected behavior is to stop the affected workflow and report the unsupported dependency; do not guess a replacement command, access NAS files directly, or route around the registered expert.
