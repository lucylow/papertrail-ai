---
name: papertrail-ai
description: Turn user-authorized NAS business documents into evidence-linked vendor spending answers and invoice/contract reconciliations. Use when a user asks to extract finance facts, summarize spending, compare related records, or prepare a source-backed report from a specified NAS folder.
---

# Goal

Answer business-finance questions from files the user authorizes on their UGREEN NAS. Return a useful total, a line-by-line evidence trail, and clear exceptions. Distinguish amounts billed from amounts paid; do not add a receipt that supports an invoice to the invoice-billed subtotal. Treat discrepancies as review flags, not proof of error or fraud. Never infer a missing invoice unless the user provides an expected schedule or source record.

# Required input

- A user-authorized NAS folder or file scope. If absent or ambiguous, ask before searching.
- The user's question, vendor, and period when relevant.
- For spending totals, the intended basis: invoices billed, documented payments, or standalone receipt amounts. If unclear, ask before reporting one combined total.
- Optional: an expected billing schedule or explicit comparison records when checking for missing documents.
- Optional: a destination only if the user wants the report saved.

Search only the authorized scope. Do not access unrelated folders, transmit file content externally, or alter source documents. If the user's privacy requirement conflicts with the NAS model's configured processing or data-sharing policy, pause and clarify rather than assume the model runs locally.

# Generation-time capability evidence

- `ug-filesystem` → `file-agent`
- `ug-document` → `document-agent`
- `ug-knowledge` → `knowledge-agent`

# Workflow

Use only registered expert delegation. The parent Skill does not execute NAS CLI operations directly. All platform authorization and approval gates remain in effect.

1. Confirm the question, authorized scope, period, vendor, currency, and spending basis. If scope or basis is unclear, ask the user and wait.
2. On each request, delegate fresh scoped discovery to `file-agent` through `ug-filesystem.find`; use `ls` only when a scoped listing is needed. Pass only real paths returned by discovery to document operations. If discovery returns no results or no relevant files, report no match and stop; never widen the search or substitute unrelated files. If coverage is limited, bound the answer to returned files. Do not claim cached, persistent, or background monitoring.

   `delegate --target file-agent --instruction 'Search only the finance documents in the NAS folder the user authorized for this request; return real file paths, coverage, and an explicit no-match result.'`
3. Delegate extraction to `document-agent` through `ug-document.extract` using the applicable invoice, receipt, contract, purchase-order, or mixed schema. Request document type, vendor, invoice or reference number, dates, currency, amounts, tax, and payment terms when present. Preserve extraction failures and coverage warnings.

   `delegate --target document-agent --instruction 'Extract supported finance fields only from verified NAS document paths within the user-authorized scope; return source paths, dates, currency, values, evidence, coverage, and failures without guessing.'`
4. For questions about individual evidence, delegate `ug-document.qa` against identified files. For contract comparisons or a possible invoice/receipt match, delegate `ug-document.reconcile` with the exact related paths and a focused question. Use only real results from completed discovery and extraction; do not invent relationships or silently deduplicate uncertain matches.

   `delegate --target document-agent --instruction 'Reconcile only verified related finance documents within the user-authorized scope; report the compared evidence, result, source paths, coverage, and limitations.'`
5. For a requested total, aggregate one basis at a time: invoice-billed amounts, explicitly documented payments, or standalone receipt amounts. A receipt supporting an invoice is evidence, not an additional billed expense. If a possible duplicate is unresolved, show separate subtotals and the possible overlap; do not assert a unique-spend grand total. Run a separate `ug-document.qa` check on the exact extracted files for amounts, dates, currencies, and supporting evidence. If that check conflicts or is incomplete, report uncertainty and line items instead of a total. Otherwise show the calculation, keep currencies and periods distinct, and link each material figure to its source path and any returned page or evidence detail.

   `delegate --target document-agent --instruction 'Verify the requested vendor and period totals against the exact verified NAS file paths used by completed extraction; return amount, date, currency, source evidence, coverage, and any disagreement without guessing.'`
6. Label differences as “needs review.” Describe causes such as tax, amendments, timing, or added services only as possibilities. Do not approve payments or characterize a difference as overbilling.
7. If the user asks to save the report, confirm a destination if needed, then delegate `ug-knowledge.save-text` to `knowledge-agent`. This is approval-gated. Wait for approval and verified output. Never move, rename, delete, or overwrite source files.

   `delegate --target knowledge-agent --instruction 'Save the final report only after the user explicitly requests it and confirms the destination; use the approved save workflow and return verified output or the approval status.'`

# Result format

Return the result in this order:

1. **Answer:** requested basis, period, currency, and checked subtotal, or say why no total is supported.
2. **Evidence:** one source-linked line per included document, with date, amount, and role in the subtotal; include page detail when returned.
3. **Exceptions:** possible overlap, contract difference, expected item not found in the searched scope, extraction failure, or incomplete coverage.
4. **Scope:** authorized folder searched and relevant files returned/read. State what the files do not establish; never turn “not found here” into “does not exist.”

# Completion and failure

- `completed`: provide the result, scope searched, coverage limitations, and source paths. Claim a saved report only when save output confirms it.
- `failed`: state which step failed, include the useful reason, and do not present its intended result as fact. Retry only if the expert or user indicates a safe retry.
- `cancelled`: say the task was cancelled and provide no success claim.
- `waiting_user`: ask only for the missing scope, clarification, or choice; do not continue with a guess.
- `waiting_approval`: state that the approval-gated action is pending and do not claim it happened.
- Partial results: identify unavailable documents or steps, report only supported findings, and stop dependent work when required evidence is missing.

# Runtime and data handling

Inputs are the user's request, authorized NAS paths, and optional comparison records or schedule. The workflow uses UGREEN's registered file, document, and knowledge experts. This package was authored against Uliya Skill Creation Tool v0.7.3 and capability catalog v2.0.0; before device testing, verify the active catalog and agent mappings. If a required action is unavailable or the mapping differs, stop and report it as unsupported rather than substituting a command. Use only the model and processing configuration approved for the user's data; do not name a model as supported until verified on the target NAS. No external API, credentials, third-party library, script, or service is required by this Skill. Confirm target-device model, permission boundaries, model data policy, repeat-use behavior, and extraction accuracy during finalist testing before claiming local-only inference or runtime compatibility.

# Development disclosure

This Hackathon submission's original functionality is scoped discovery, finance-field extraction, cross-document reconciliation, duplicate-aware totals, evidence-linked synthesis, and optional approval-gated report saving. See [disclosures](references/disclosures.md) for tools, sources, and component/license disclosures, and [synthetic acceptance scenarios](references/test-cases.md) before finalist testing.
